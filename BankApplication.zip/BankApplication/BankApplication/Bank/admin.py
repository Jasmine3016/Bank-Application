from django.contrib import admin
from .models import BankDetails
# Register your models here.

admin.site.register(BankDetails)