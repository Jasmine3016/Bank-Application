from django.shortcuts import render
import openpyxl
import psycopg2
# Create your views here.
def index(request):
    return render(request,'index.html')

def formdata(request):
    global bankname
    global IFSC_code
    global branchname
    global address
    global district
    global state
    global phoneno
    global city
    
    if request.method == 'POST':
        # filename = request.POST["file"]
        filename = request.FILES.get('file')
        print(filename)
        wb = openpyxl.load_workbook(filename)
        worksheet = wb["Sheet1"]
        print(worksheet)
        excel_data = list()
        bankname=[]
        IFSC_code=[]
        branchname=[]
        address=[]
        district =[]
        state=[]
        phoneno=[]
        city=[]
        # iterating over the rows and
        # getting value from each cell in row
        for row in worksheet.iter_rows():
            row_data = list()
            for cell in row:
                row_data.append(str(cell.value))
            excel_data.append(row_data)
            bankname.append(row_data[0])
            IFSC_code.append(row_data[1])
            branchname.append(row_data[2])
            address.append(row_data[3])
            city.append(row_data[4])
            district.append(row_data[5])
            state.append(row_data[6])
            phoneno.append(row_data[7])
        print(row_data[3])
        bankname.pop(0)
        IFSC_code.pop(0)
        branchname.pop(0)
        address.pop(0)
        city.pop(0)
        district.pop(0)
        state.pop(0)
        phoneno.pop(0)
        print(len(bankname))
        print(len(address))
        IsActive="True"
        for bankname,IFSC_code,branchname,address,city,district,state,phoneno in zip(bankname,IFSC_code,branchname,address,city,district,state,phoneno):
            print(IFSC_code)
            print(type(IFSC_code))
            connection = psycopg2.connect(user="postgres",
                                        password="123",
                                        host="localhost",
                                        port="5432",
                                        database="demo")
            cursor = connection.cursor()
            # sql='SELECT "BankName","IFSC_Code","Branch_Name","Address","City1","district","State","Phoneno","IsActive" FROM "Bank_bankdetails" WHERE "IFSC_Code"= %s'
            # data=(IFSC_code)
            # cursor.execute(sql,data)
            cursor.execute('SELECT "BankName","IFSC_Code","Branch_Name","Address","City1","district","State","Phoneno","IsActive" FROM "Bank_bankdetails" WHERE "IFSC_Code"= %s',[IFSC_code])
            record = cursor.fetchall()
            results=[]
            for row in record:
                for x in row:
                    results.append(x)
            print(len(results))
            if len(results) !=0:
                sqlquery='update "Bank_bankdetails" set "BankName"=%s,"Branch_Name"=%s,"Address"=%s,"City1"=%s,"district"=%s,"State"=%s,"Phoneno"=%s WHERE "IFSC_Code"= %s'
                data=(bankname,branchname,address,city,district,state,phoneno,IFSC_code)
                cursor.execute(sqlquery,(bankname,branchname,address,city,district,state,phoneno,IFSC_code,))
                cursor.execute('select "BankName","IFSC_Code","Branch_Name","Address","City1","district","State","Phoneno","IsActive" from "Bank_bankdetails" ')
                data=cursor.fetchall()
                connection.commit()
            else:
                active="False"
                sqlquery='update "Bank_bankdetails" set "IsActive"=%s'
                cursor.execute(sqlquery,(active,))
                postgres_insert_query = 'INSERT INTO "Bank_bankdetails" ("BankName","IFSC_Code","Branch_Name","Address","City1","district","State","Phoneno","IsActive") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                record_to_insert = (bankname,IFSC_code,branchname,address,city,district,state,phoneno,IsActive)
                cursor.execute(postgres_insert_query, record_to_insert)
                cursor.execute('select "BankName","IFSC_Code","Branch_Name","Address","City1","district","State","Phoneno","IsActive" from "Bank_bankdetails" ')
                data=cursor.fetchall()
                connection.commit()
        print("sucess")
        print(data)
        bankname1=[]
        IFSC_code1=[]
        branchname1=[]
        address1=[]
        district1 =[]
        state1=[]
        phoneno1=[]
        city1=[]
        for i in data:
            data=[]
            for j in i:
                data.append(j)
                print(data)
            bankname1.append(data[0])
            IFSC_code1.append(data[1])
            branchname1.append(data[2])
            address1.append(data[3])
            city1.append(data[4])
            district1.append(data[5])
            state1.append(data[6])
            phoneno1.append(data[7])
                
        data = [{'Bank': bankname, 'IFSC': IFSC_code, 'Branch': branchname,'Address':address,'City':city,'Distict':district,'State':state,'Phone':phoneno}for bankname,IFSC_code,branchname,address,city,district,state,phoneno in zip(bankname1,IFSC_code1,branchname1,address1,city1,district1,state1,phoneno1)]
        # print(data)
        print("Sucess")
    return render(request,'table.html',{'data':data})