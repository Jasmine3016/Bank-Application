from django.db import models

# Create your models here.
class BankDetails(models.Model):
    BankName = models.CharField(max_length=200)
    IFSC_Code = models.CharField(max_length=200)
    Branch_Name = models.CharField(max_length=200)
    Address = models.CharField(max_length=500)
    City1 = models.CharField(max_length=200)
    district = models.CharField(max_length=200)
    State = models.CharField(max_length=200)
    Phoneno = models.CharField(max_length=20)
    IsActive = models.BooleanField(default=True)
